import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  beforeLoad: () => {
    throw redirect({ href: "/channel/index.html" });
  },
  component: Home,
});

function Home() {
  return (
    <main className="p-8">
      <p>Opening Channel Crossings…</p>
      <a href="/channel/index.html">Continue to the map</a>
    </main>
  );
}
