import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CwDoo_Ks.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "p-8",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Opening Channel Crossings…" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
			href: "/channel/index.html",
			children: "Continue to the map"
		})]
	});
}
//#endregion
export { Home as component };
