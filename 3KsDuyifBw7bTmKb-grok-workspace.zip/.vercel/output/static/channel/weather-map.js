/* Live Channel weather. Wind, waves and a small-boat crossing outlook.
   Readings: Open-Meteo (forecast + marine). Map tiles: Esri Light Gray. */
(function () {
  const LAT0 = 49.5, DLAT = 0.25, NLAT = 10;
  const LON0 = -0.55, DLON = 0.35, NLON = 11;
  const LATS = Array.from({ length: NLAT }, (_, i) => +(LAT0 + i * DLAT).toFixed(2));
  const LONS = Array.from({ length: NLON }, (_, i) => +(LON0 + i * DLON).toFixed(2));
  const ENGLAND = [[50.72,-0.55],[50.74,-0.1],[50.76,0.27],[50.86,0.59],[50.91,0.98],[51.05,1.14],[51.13,1.32],[51.22,1.40],[51.33,1.42],[51.39,1.30],[51.44,0.95],[51.50,0.70],[51.54,0.30],[51.62,-0.05],[51.72,-0.45],[51.45,-0.75],[50.95,-0.85],[50.72,-0.55]];
  const FRANCE = [[51.09,2.58],[51.05,2.37],[51.01,2.14],[50.97,1.86],[50.90,1.62],[50.87,1.58],[50.77,1.60],[50.72,1.59],[50.60,1.58],[50.50,1.60],[50.22,1.55],[49.93,1.08],[49.70,0.30],[49.49,0.10],[49.34,-0.15],[49.18,0.50],[49.55,2.20],[50.10,2.90],[50.55,3.45],[50.95,3.55],[51.22,3.30],[51.28,2.85],[51.12,2.62],[51.09,2.58]];
  const TOWNS = [["Dover",51.127,1.313],["Folkestone",51.081,1.170],["Ramsgate",51.336,1.416],["Calais",50.958,1.852],["Dunkirk",51.034,2.377],["Boulogne",50.726,1.615],["Deal",51.223,1.403]];
  const BEACHES = [["Dunkirk beaches",51.045,2.30,"Loon-Plage and the beaches east of Dunkirk"],["Gravelines",51.003,2.11,"Beaches and the Aa canal by Gravelines"],["Calais to Sangatte",50.955,1.78,"Beaches west of Calais and Blériot-Plage"],["Wimereux",50.77,1.605,"Wimereux and the dunes of the Slack"],["Boulogne to Hardelot",50.66,1.575,"Le Portel, Équihen-Plage and Hardelot"],["Le Touquet",50.52,1.585,"The Canche estuary and Stella-Plage"]];
  const ROUTES = [[[50.97,1.85],[51.12,1.33]],[[51.04,2.22],[51.22,1.40]],[[50.73,1.60],[50.92,0.99]]];
  const COMPASS = ["north","north-east","east","south-east","south","south-west","west","north-west"];
  const WORD = {calm:"Crossings likely", moderate:"Crossings possible", rough:"Crossings unlikely"};
  const LAYERS = [
    ["crossing","Crossing"],
    ["wind","Wind"],
    ["waves","Waves"],
    ["gusts","Gusts"],
    ["rain","Rain"]
  ];
  const SCALES = {
    crossing:{stops:[[0,[255,69,58]],[40,[255,159,10]],[70,[52,199,89]]],lo:"Unlikely",hi:"Likely"},
    wind:{stops:[[0,[120,170,220]],[8,[72,180,170]],[14,[120,190,90]],[20,[230,200,70]],[28,[230,140,50]],[36,[200,60,70]]],lo:"0",hi:"40+ mph"},
    waves:{stops:[[0,[90,160,220]],[0.4,[70,190,170]],[0.8,[140,200,90]],[1.3,[232,198,70]],[2,[220,120,50]],[3,[190,50,80]]],lo:"0",hi:"3+ m"},
    gusts:{stops:[[0,[120,170,220]],[12,[72,180,170]],[20,[120,190,90]],[28,[230,170,60]],[36,[220,90,50]],[48,[180,40,80]]],lo:"0",hi:"50+ mph"},
    rain:{stops:[[0,[170,200,230]],[0.4,[80,140,220]],[1.5,[90,90,200]],[4,[170,60,170]]],lo:"0",hi:"4+ mm"}
  };

  function inPoly(lat, lon, poly) {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const yi = poly[i][0], xi = poly[i][1], yj = poly[j][0], xj = poly[j][1];
      if ((yi > lat) !== (yj > lat) && lon < ((xj - xi) * (lat - yi)) / (yj - yi + 1e-12) + xi) inside = !inside;
    }
    return inside;
  }
  const atSea = (lat, lon) => !inPoly(lat, lon, ENGLAND) && !inPoly(lat, lon, FRANCE);
  const level = (w, v) => (w == null || v == null ? null : w < 12 && v < 0.5 ? "calm" : w < 18 && v < 1 ? "moderate" : "rough");
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  function scoreOf(w, v) {
    if (w == null || v == null) return null;
    const ws = clamp(1 - w / 28, 0, 1), vs = clamp(1 - v / 2.2, 0, 1);
    return Math.round(100 * Math.min(ws, vs));
  }
  function colour(v, stops) {
    if (v == null) return [140, 160, 180];
    if (v <= stops[0][0]) return stops[0][1];
    for (let i = 1; i < stops.length; i++) {
      if (v <= stops[i][0]) {
        const t = (v - stops[i - 1][0]) / (stops[i][0] - stops[i - 1][0]);
        return stops[i - 1][1].map((c, n) => c + (stops[i][1][n] - c) * t);
      }
    }
    return stops[stops.length - 1][1];
  }
  function sample(lat, lon, arr) {
    if (!arr) return null;
    const fy = clamp((lat - LAT0) / DLAT, 0, NLAT - 1.001);
    const fx = clamp((lon - LON0) / DLON, 0, NLON - 1.001);
    const i = fy | 0, j = fx | 0, ty = fy - i, tx = fx - j;
    const at = (r, c) => arr[r * NLON + c];
    const a = at(i, j), b = at(i, j + 1), c = at(i + 1, j), d = at(i + 1, j + 1);
    if (a == null || b == null || c == null || d == null) return a ?? b ?? c ?? d;
    return (a * (1 - tx) + b * tx) * (1 - ty) + (c * (1 - tx) + d * tx) * ty;
  }
  function fillGaps(arr) {
    if (!arr || !arr.some(v => v != null)) return arr;
    let a = arr.slice();
    for (let pass = 0; pass < 8 && a.some(v => v == null); pass++) {
      a = a.map((v, k) => {
        if (v != null) return v;
        const r = (k / NLON) | 0, c = k % NLON, n = [];
        [[r - 1, c], [r + 1, c], [r, c - 1], [r, c + 1]].forEach(([i, j]) => {
          if (i >= 0 && i < NLAT && j >= 0 && j < NLON && a[i * NLON + j] != null) n.push(a[i * NLON + j]);
        });
        return n.length ? n.reduce((p, q) => p + q, 0) / n.length : null;
      });
    }
    return a;
  }
  const ukStamp = () => new Date().toLocaleString("sv-SE", { timeZone: "Europe/London" }).slice(0, 13).replace(" ", "T");
  function whenLabel(t, nowT) {
    if (!t) return "";
    if (t.slice(0, 13) === nowT) return "Now";
    const [y, m, d] = t.slice(0, 10).split("-").map(Number);
    const wd = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][new Date(Date.UTC(y, m - 1, d)).getUTCDay()];
    const today = nowT.slice(0, 10);
    return (t.slice(0, 10) === today ? "" : wd + " ") + t.slice(11, 16);
  }
  function tailNote(dir, mph) {
    if (mph < 6 || dir == null) return "";
    const toward = (dir + 180) % 360;
    let d = Math.abs(toward - 300) % 360;
    if (d > 180) d = 360 - d;
    if (d < 45) return "Following wind toward Kent";
    if (d > 125) return "Headwind off the Kent coast";
    return "Crosswind on the usual routes";
  }
  function sentence(series, idx) {
    const cur = series[idx];
    if (!cur || !cur.lvl) return "Waiting for the sea state.";
    const name = { calm: "Crossings are likely", moderate: "Some crossings are possible", rough: "Crossings are unlikely" }[cur.lvl];
    let end = idx;
    while (end < series.length && series[end].lvl === cur.lvl) end++;
    const stay = end - idx;
    if (cur.lvl !== "calm") {
      const calm = series.findIndex((s, k) => k > idx && s.lvl === "calm");
      if (calm > 0) return name + " just now. A calmer window opens " + whenLabel(series[calm].t, series[idx].t) + ".";
    }
    if (stay >= 12) return name + " across the next " + stay + " hours.";
    if (stay <= 2) return name + ", but only for an hour or two.";
    return name + " for about the next " + stay + " hours.";
  }

  let map, heat, flow, pane, hours = [], hourNow = 0, hourIdx = 0, layer = "crossing";
  let fld = null, parts = [], raf = 0, playing = 0, reduced = false, onReady = null, failed = false;
  let vw = 0, vh = 0, dpr = 1, built = false;

  function valAt(lat, lon, h) {
    const s = hours[h];
    if (!s) return {};
    const wind = sample(lat, lon, s.wind), gust = sample(lat, lon, s.gust);
    const dir = sample(lat, lon, s.dir), wave = sample(lat, lon, s.wave);
    const wdir = sample(lat, lon, s.wdir), rain = sample(lat, lon, s.rain);
    const temp = sample(lat, lon, s.temp);
    return { wind, gust, dir, wave, wdir, rain, temp, lvl: level(wind, wave), score: scoreOf(wind, wave) };
  }
  function layerValue(p) {
    if (layer === "crossing") return p.score;
    if (layer === "waves") return p.wave;
    if (layer === "gusts") return p.gust;
    if (layer === "rain") return p.rain;
    return p.wind;
  }
  function flowVec(p) {
    const dir = layer === "waves" && p.wind < 6 && p.wdir != null ? p.wdir : p.dir;
    const spd = layer === "waves" ? 3 + (p.wave || 0) * 5 : layer === "gusts" ? (p.gust || p.wind || 0) : (p.wind || 0);
    if (dir == null) return { x: 0, y: 0, s: 0 };
    const r = dir * Math.PI / 180;
    const east = -Math.sin(r), north = -Math.cos(r);
    const k = layer === "waves" ? 1.1 : 1.45;
    return { x: east * spd * k, y: -north * spd * k, s: spd };
  }

  function layout() {
    if (!map) return;
    const sz = map.getSize();
    vw = sz.x; vh = sz.y;
    if (!vw || !vh) return;
    dpr = Math.min(2, devicePixelRatio || 1);
    [heat, flow].forEach(c => {
      c.width = vw * dpr; c.height = vh * dpr;
      c.style.width = vw + "px"; c.style.height = vh + "px";
    });
    const tl = map.containerPointToLayerPoint([0, 0]);
    L.DomUtil.setPosition(heat, tl);
    L.DomUtil.setPosition(flow, tl);
  }

  function drawField() {
    if (!map || !hours.length || !vw) return;
    const step = 7, cols = Math.ceil(vw / step) + 1, rows = Math.ceil(vh / step) + 1;
    const sea = new Uint8Array(cols * rows);
    const u = new Float32Array(cols * rows), v = new Float32Array(cols * rows), m = new Float32Array(cols * rows);
    const off = document.createElement("canvas");
    off.width = cols; off.height = rows;
    const ox = off.getContext("2d");
    const img = ox.createImageData(cols, rows);
    const px = img.data;
    const stops = SCALES[layer].stops;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const k = r * cols + c;
        const ll = map.containerPointToLatLng([c * step, r * step]);
        const seaHere = atSea(ll.lat, ll.lng);
        sea[k] = seaHere ? 1 : 0;
        const p = valAt(ll.lat, ll.lng, hourIdx);
        const fv = flowVec(p);
        u[k] = fv.x; v[k] = fv.y; m[k] = fv.s;
        const q = k * 4;
        if (!seaHere) { px[q + 3] = 0; continue; }
        const col = colour(layerValue(p), stops);
        px[q] = col[0]; px[q + 1] = col[1]; px[q + 2] = col[2];
        px[q + 3] = layer === "rain" && (p.rain || 0) < 0.05 ? 0 : layer === "crossing" ? 168 : 188;
      }
    }
    ox.putImageData(img, 0, 0);
    const h = heat.getContext("2d");
    h.setTransform(dpr, 0, 0, dpr, 0, 0);
    h.clearRect(0, 0, vw, vh);
    h.imageSmoothingEnabled = true;
    h.filter = "blur(8px)";
    h.drawImage(off, -step / 2, -step / 2, cols * step, rows * step);
    h.filter = "none";
    fld = { cols, rows, step, sea, u, v, m };
    if (!parts.length || parts.length !== particleCount()) resetParts();
  }
  function particleCount() {
    const area = vw * vh;
    return Math.round(layer === "waves" ? Math.min(420, area / 2800) : Math.min(reduced ? 500 : 1100, area / 900));
  }
  function spawn(p) {
    for (let i = 0; i < 8; i++) {
      p.x = Math.random() * vw; p.y = Math.random() * vh;
      if (!fld || fld.sea[cell(p.x, p.y)]) break;
    }
    p.age = 0; p.max = 80 + Math.random() * 120; p.px = p.x; p.py = p.y;
    return p;
  }
  function resetParts() {
    parts = Array.from({ length: particleCount() }, () => spawn({}));
    parts.forEach(p => { p.age = Math.random() * p.max; });
    if (flow) flow.getContext("2d").clearRect(0, 0, flow.width, flow.height);
  }
  function cell(x, y) {
    const c = clamp(Math.round(x / fld.step), 0, fld.cols - 1);
    const r = clamp(Math.round(y / fld.step), 0, fld.rows - 1);
    return r * fld.cols + c;
  }
  function vel(x, y, arr) {
    const fx = clamp(x / fld.step, 0, fld.cols - 1.001), fy = clamp(y / fld.step, 0, fld.rows - 1.001);
    const i = fy | 0, j = fx | 0, tx = fx - j, ty = fy - i, C = fld.cols, k = i * C + j;
    return (arr[k] * (1 - tx) + arr[k + 1] * tx) * (1 - ty) + (arr[k + C] * (1 - tx) + arr[k + C + 1] * tx) * ty;
  }
  function step(dt) {
    if (!fld || !flow || document.hidden) return;
    const c = flow.getContext("2d");
    c.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (layer === "waves") stepWaves(c, dt);
    else stepWind(c, dt);
  }
  function stepWind(c, dt) {
    c.globalCompositeOperation = "destination-in";
    c.fillStyle = "rgba(0,0,0," + Math.pow(0.88, dt).toFixed(3) + ")";
    c.fillRect(0, 0, vw, vh);
    c.globalCompositeOperation = "source-over";
    c.lineCap = "round";
    const paths = Array.from({ length: 4 }, () => new Path2D());
    for (const p of parts) {
      if (!fld.sea[cell(p.x, p.y)]) { spawn(p); continue; }
      const dx = vel(p.x, p.y, fld.u) * 0.055 * dt, dy = vel(p.x, p.y, fld.v) * 0.055 * dt;
      p.age += dt;
      const nx = p.x + dx, ny = p.y + dy;
      if (p.age > p.max || nx < 0 || ny < 0 || nx > vw || ny > vh) { spawn(p); continue; }
      const t = p.age / p.max, life = Math.min(1, t * 5, (1 - t) * 4);
      const P = paths[Math.min(3, (life * 4) | 0)];
      P.moveTo(p.px, p.py); P.quadraticCurveTo(p.x, p.y, nx, ny);
      p.px = p.x; p.py = p.y; p.x = nx; p.y = ny;
    }
    for (let i = 0; i < 4; i++) {
      c.strokeStyle = "rgba(255,255,255," + (0.18 + i * 0.16).toFixed(2) + ")";
      c.lineWidth = layer === "gusts" ? 1.25 : 1.05;
      c.stroke(paths[i]);
    }
  }
  function stepWaves(c, dt) {
    c.clearRect(0, 0, vw, vh);
    c.lineCap = "round";
    const paths = Array.from({ length: 3 }, () => new Path2D());
    for (const p of parts) {
      p.age += dt;
      if (p.age > p.max || !fld.sea[cell(p.x, p.y)]) { spawn(p); continue; }
      let dx = vel(p.x, p.y, fld.u), dy = vel(p.x, p.y, fld.v);
      const n = Math.hypot(dx, dy) || 1; dx /= n; dy /= n;
      p.x += dx * 0.35 * dt; p.y += dy * 0.35 * dt;
      const fade = Math.sin(Math.PI * p.age / p.max);
      if (fade < 0.08) continue;
      const P = paths[Math.min(2, (fade * 3) | 0)];
      const ang = Math.atan2(dy, dx), half = 7;
      P.moveTo(p.x - dy * half, p.y + dx * half);
      P.quadraticCurveTo(p.x + dx * 3, p.y + dy * 3, p.x + dy * half, p.y - dx * half);
    }
    for (let i = 0; i < 3; i++) {
      c.strokeStyle = "rgba(255,255,255," + (0.25 + i * 0.22).toFixed(2) + ")";
      c.lineWidth = 1.4;
      c.stroke(paths[i]);
    }
  }
  function frame(t) {
    raf = 0;
    if (reduced || !fld) return;
    step(1);
    const hero = document.getElementById("hero");
    if (hero && hero.getBoundingClientRect().bottom > 0 && hero.getBoundingClientRect().top < innerHeight) {
      raf = requestAnimationFrame(frame);
    }
  }
  function wake() { if (!reduced && !raf) raf = requestAnimationFrame(frame); }

  function seriesAtStrait() {
    return hours.map(h => {
      const p = valAt(51, 1.55, hours.indexOf(h));
      return { t: h.t, lvl: p.lvl, wind: p.wind, wave: p.wave, gust: p.gust, dir: p.dir };
    });
  }
  function paintVerdict() {
    const el = document.getElementById("cmVerdict");
    if (!el) return;
    const nowT = ukStamp();
    if (failed || !hours.length) {
      el.dataset.lv = "";
      el.innerHTML = '<p class="cm-k">Dover Strait</p><p class="cm-h">Weather unavailable</p><p class="cm-why">The weather service did not respond. The figures below are unchanged. Trying again shortly.</p>';
      return;
    }
    const s = seriesAtStrait();
    const cur = s[hourIdx] || s[hourNow];
    el.dataset.lv = cur.lvl || "";
    const why = sentence(s, hourIdx);
    const note = tailNote(cur.dir, cur.wind);
    el.innerHTML = '<p class="cm-k">Dover Strait · ' + whenLabel(hours[hourIdx].t, nowT) + '</p>'
      + '<p class="cm-h">' + (cur.lvl ? WORD[cur.lvl] : "Reading the sea") + '</p>'
      + '<p class="cm-why">' + why + (note ? " " + note + "." : "") + '</p>'
      + '<div class="cm-stats"><div><span>Wind</span><b>' + (cur.wind == null ? "–" : Math.round(cur.wind) + " mph") + '</b></div>'
      + '<div><span>Waves</span><b>' + (cur.wave == null ? "–" : cur.wave.toFixed(1) + " m") + '</b></div>'
      + '<div><span>Gusts</span><b>' + (cur.gust == null ? "–" : Math.round(cur.gust) + " mph") + '</b></div></div>'
      + '<div class="cm-strip" role="listbox" aria-label="Crossing outlook, next two days">' + s.map((h, i) =>
        '<button type="button" class="' + (h.lvl || "") + (i === hourIdx ? " on" : "") + '" data-h="' + i + '" aria-label="' + whenLabel(h.t, nowT) + " " + (h.lvl ? WORD[h.lvl] : "") + '"></button>').join("") + '</div>'
      + '<div class="cm-times"><span>' + whenLabel(s[0].t, nowT) + '</span><span>Next 48 hours</span><span>' + whenLabel(s[s.length - 1].t, nowT) + '</span></div>';
    el.querySelectorAll(".cm-strip button").forEach(b => b.addEventListener("click", e => {
      e.stopPropagation();
      stopPlay();
      goHour(+b.dataset.h);
    }));
  }
  function paintKey() {
    const key = document.getElementById("cmKey");
    if (!key) return;
    const sc = SCALES[layer];
    const grad = sc.stops.map(([v, c], i, a) => {
      const lo = a[0][0], hi = a[a.length - 1][0];
      return "rgb(" + c.map(Math.round).join(",") + ") " + ((v - lo) / (hi - lo) * 100).toFixed(0) + "%";
    }).join(",");
    key.innerHTML = "<span>" + sc.lo + '</span><i style="background:linear-gradient(to right,' + grad + ')"></i><span>' + sc.hi + "</span>";
  }
  function paintWhen() {
    const lab = document.getElementById("cmWhen");
    const slider = document.getElementById("cmHour");
    if (!lab || !slider || !hours.length) return;
    lab.textContent = whenLabel(hours[hourIdx].t, ukStamp());
    slider.max = hours.length - 1;
    slider.value = hourIdx;
    slider.style.setProperty("--p", (hours.length > 1 ? hourIdx / (hours.length - 1) * 100 : 0) + "%");
  }
  function goHour(i) {
    hourIdx = clamp(i, 0, Math.max(0, hours.length - 1));
    paintWhen();
    paintVerdict();
    drawField();
    if (flow) flow.getContext("2d").clearRect(0, 0, flow.width, flow.height);
    wake();
    if (pinned) showPoint(pinned, true);
  }
  function stopPlay() {
    clearInterval(playing); playing = 0;
    const b = document.getElementById("cmPlay");
    if (b) { b.setAttribute("aria-pressed", "false"); b.setAttribute("aria-label", "Play the forecast"); }
  }
  function togglePlay() {
    if (playing) return stopPlay();
    const b = document.getElementById("cmPlay");
    if (b) { b.setAttribute("aria-pressed", "true"); b.setAttribute("aria-label", "Pause the forecast"); }
    const stepHour = () => goHour(hourIdx >= hours.length - 1 ? hourNow : hourIdx + 1);
    stepHour();
    playing = setInterval(stepHour, 700);
  }

  let pinned = null;
  function readingHtml(lat, lon) {
    const p = valAt(lat, lon, hourIdx);
    const sea = atSea(lat, lon);
    const from = p.dir == null ? "" : COMPASS[Math.round((((p.dir % 360) + 360) % 360) / 45) % 8];
    const title = sea ? (p.lvl ? WORD[p.lvl] : "At sea") : "On land";
    const sub = (sea ? "At sea" : "On land") + " · " + (hours[hourIdx] ? whenLabel(hours[hourIdx].t, ukStamp()) : "") + (from ? " · wind from the " + from : "");
    const cell = (n, v, u) => "<div><span>" + n + '</span><b class="num">' + v + "</b><small> " + u + "</small></div>";
    return '<b class="pt-h">' + title + "</b>"
      + '<span class="pt-sub">' + sub + "</span>"
      + (sea && p.lvl ? '<span class="pt-lv ' + p.lvl + '">' + WORD[p.lvl] + "</span>" : "")
      + '<div class="wp-stats">' + cell("Wind", p.wind == null ? "–" : Math.round(p.wind), "mph")
      + cell("Gusts", p.gust == null ? "–" : Math.round(p.gust), "mph")
      + cell("Waves", !sea || p.wave == null ? "–" : p.wave.toFixed(1), "m") + "</div>"
      + '<div class="wp-stats">' + cell("Temp", p.temp == null ? "–" : Math.round(p.temp), "°C")
      + cell("Rain", p.rain == null ? "–" : p.rain.toFixed(1), "mm") + cell("From", from ? from : "–", "") + "</div>"
      + (sea ? "<p class=\"pt-sub\" style=\"margin-top:8px\">Calm means wind under 12 mph and waves under 0.5 m. That is when small boats usually set out.</p>" : "");
  }
  function showPoint(ll, keep) {
    if (!map) return;
    pinned = ll;
    const coarse = matchMedia("(pointer:coarse)").matches || innerWidth < 720;
    const html = readingHtml(ll.lat, ll.lng);
    if (!keep) {
      const icon = L.divIcon({ className: "am-pin", html: "<s></s><b></b><i></i>", iconSize: [22, 30], iconAnchor: [11, 29] });
      if (!showPoint.pin) showPoint.pin = L.marker(ll, { icon, interactive: false, keyboard: false }).addTo(map);
      else showPoint.pin.setLatLng(ll);
    }
    if (coarse) {
      map.closePopup();
      const sh = document.getElementById("amSheet");
      if (!sh) return;
      sh.querySelector(".am-sheet-in").innerHTML = html;
      if (sh.hidden) { sh.hidden = false; sh.classList.remove("in"); sh.offsetWidth; sh.classList.add("in"); }
      return;
    }
    const sheet = document.getElementById("amSheet");
    if (sheet) sheet.hidden = true;
    L.popup({ className: "wx-pt", closeButton: false, offset: [0, -18], maxWidth: 260, autoPanPadding: [16, 80] })
      .setLatLng(ll).setContent(html).openOn(map);
  }
  function showHover(e) {
    const box = document.getElementById("amHover");
    if (!box || !e || matchMedia("(hover: none)").matches) return;
    const p = valAt(e.latlng.lat, e.latlng.lng, hourIdx);
    if (!atSea(e.latlng.lat, e.latlng.lng)) { box.classList.add("off"); return; }
    const bit = layer === "waves" ? (p.wave == null ? "–" : p.wave.toFixed(1) + " m")
      : layer === "rain" ? (p.rain == null ? "–" : p.rain.toFixed(1) + " mm")
      : layer === "gusts" ? Math.round(p.gust || 0) + " mph"
      : Math.round(p.wind || 0) + " mph";
    box.innerHTML = "<b>" + bit + "</b><em>" + (p.lvl ? WORD[p.lvl] : "") + "</em>";
    box.classList.remove("off");
    const hero = document.getElementById("hero").getBoundingClientRect();
    const m = document.getElementById("lmap").getBoundingClientRect();
    let x = e.containerPoint.x + m.left - hero.left + 14;
    let y = e.containerPoint.y + m.top - hero.top + 16;
    if (x + box.offsetWidth > hero.width - 8) x -= box.offsetWidth + 28;
    box.style.transform = "translate(" + Math.round(x) + "px," + Math.round(y) + "px)";
  }

  function fitView() {
    if (!map) return;
    map.invalidateSize({ pan: false });
    const narrow = map.getSize().x < 700;
    const bounds = narrow ? L.latLngBounds([50.62, 0.85], [51.28, 2.05]) : L.latLngBounds([50.35, 0.15], [51.48, 2.55]);
    const bottom = document.querySelector(".hero-in");
    const padB = bottom ? Math.max(120, bottom.offsetHeight + 24) : 180;
    const top = document.querySelector(".large-title");
    const padT = top ? top.offsetHeight + 36 : 120;
    map.fitBounds(bounds, { paddingTopLeft: [24, padT], paddingBottomRight: [narrow ? 16 : 70, padB], animate: false });
  }
  function placeChrome() {
    const hero = document.getElementById("hero");
    const stage = document.getElementById("heroStage");
    const title = hero && hero.querySelector(".large-title");
    const verdict = document.getElementById("cmVerdict");
    const ctl = document.getElementById("wxCtl");
    const figures = hero && hero.querySelector(".hero-in");
    if (!hero || !title) return;
    const narrow = hero.clientWidth < 760;
    const hr = hero.getBoundingClientRect();
    const tr = title.getBoundingClientRect();
    if (ctl) {
      if (narrow) {
        ctl.style.transform = "none";
        ctl.style.left = "12px";
        ctl.style.right = "12px";
        ctl.style.top = Math.round(tr.bottom - hr.top + 6) + "px";
      } else {
        ctl.style.transform = "";
        ctl.style.left = "";
        ctl.style.right = "";
        ctl.style.top = "";
      }
    }
    if (stage && !narrow) {
      stage.style.visibility = "";
      stage.style.left = "";
      stage.style.width = "";
      stage.style.top = Math.round(tr.bottom - hr.top + 8) + "px";
    }
    if (verdict) {
      verdict.classList.toggle("cm-slim", narrow);
      if (narrow && figures) {
        const fr = figures.getBoundingClientRect();
        verdict.style.top = "auto";
        verdict.style.bottom = Math.round(hr.bottom - fr.top + 8) + "px";
      } else if (stage) {
        verdict.style.bottom = "";
        const sr = stage.getBoundingClientRect();
        const tr2 = title.getBoundingClientRect();
        verdict.style.top = Math.round(Math.max(tr2.bottom, sr.bottom) - hr.top + 12) + "px";
        verdict.classList.remove("cm-slim");
      }
    }
    if (stage && narrow && ctl && verdict && figures) {
      const gapTop = ctl.getBoundingClientRect().bottom + 8;
      const gapBot = verdict.getBoundingClientRect().top - 8;
      if (gapBot - gapTop < 52) stage.style.visibility = "hidden";
      else {
        stage.style.visibility = "";
        stage.style.left = "12px";
        stage.style.width = "calc(100% - 24px)";
        stage.style.top = Math.round((gapTop + gapBot) / 2 - hr.top - 22) + "px";
      }
    }
    if (verdict && figures && !narrow && verdict.getBoundingClientRect().bottom > figures.getBoundingClientRect().top - 8) {
      verdict.classList.add("cm-slim");
    }
  }

  async function load() {
    const la = [], lo = [];
    LATS.forEach(a => LONS.forEach(o => { la.push(a); lo.push(o); }));
    const q = "latitude=" + la.join(",") + "&longitude=" + lo.join(",") + "&forecast_hours=48&timezone=Europe%2FLondon";
    try {
      const [wRes, mRes] = await Promise.all([
        fetch("https://api.open-meteo.com/v1/forecast?" + q + "&hourly=wind_speed_10m,wind_direction_10m,wind_gusts_10m,precipitation,temperature_2m&wind_speed_unit=mph"),
        fetch("https://marine-api.open-meteo.com/v1/marine?" + q + "&hourly=wave_height,wave_direction&cell_selection=sea")
      ]);
      if (!wRes.ok) throw new Error("forecast");
      const w = await wRes.json();
      const m = mRes.ok ? await mRes.json() : null;
      const W = [].concat(w), M = m ? [].concat(m) : [];
      const times = W[0].hourly.time;
      hours = times.map((t, hi) => ({
        t,
        wind: W.map(r => r.hourly.wind_speed_10m[hi] || 0),
        dir: W.map(r => r.hourly.wind_direction_10m[hi] || 0),
        gust: W.map(r => r.hourly.wind_gusts_10m[hi] || 0),
        rain: W.map(r => r.hourly.precipitation[hi] || 0),
        temp: W.map(r => r.hourly.temperature_2m[hi]),
        wave: fillGaps(W.map((_, n) => M[n] && M[n].hourly ? M[n].hourly.wave_height[hi] : null)),
        wdir: fillGaps(W.map((_, n) => M[n] && M[n].hourly ? M[n].hourly.wave_direction[hi] : null))
      }));
      const now = ukStamp();
      hourNow = Math.max(0, hours.findIndex(h => h.t >= now));
      if (hourNow < 0) hourNow = 0;
      hourIdx = hourNow;
      failed = false;
      if (onReady) onReady();
    } catch (e) {
      failed = true;
      hours = [];
    }
    paintVerdict();
    paintWhen();
    paintKey();
    drawField();
    wake();
    placeChrome();
  }

  function buildControls() {
    const host = document.getElementById("wxCtl");
    if (!host || built) return;
    built = true;
    host.innerHTML = '<div class="cm-layers" role="radiogroup" aria-label="Weather layer">'
      + LAYERS.map(([id, name]) => '<button type="button" role="radio" data-layer="' + id + '" aria-checked="' + (id === layer) + '">' + name + "</button>").join("")
      + '</div><div class="cm-time"><button type="button" class="cm-play" id="cmPlay" aria-pressed="false" aria-label="Play the forecast"><svg class="pl" viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13a1 1 0 0 0 1.5.9l10.4-6.5a1 1 0 0 0 0-1.8L9.5 4.6A1 1 0 0 0 8 5.5z" fill="currentColor"/></svg><svg class="pa" viewBox="0 0 24 24" aria-hidden="true"><rect x="6" y="5" width="4" height="14" rx="1.2" fill="currentColor"/><rect x="14" y="5" width="4" height="14" rx="1.2" fill="currentColor"/></svg></button>'
      + '<input type="range" id="cmHour" min="0" max="0" value="0" aria-label="Forecast time"><span id="cmWhen">Now</span></div>'
      + '<div class="cm-key" id="cmKey"></div><p class="cm-note">Esri · Open-Meteo</p>';
    host.querySelectorAll(".cm-layers button").forEach(b => b.addEventListener("click", () => {
      layer = b.dataset.layer;
      host.querySelectorAll(".cm-layers button").forEach(x => x.setAttribute("aria-checked", x === b ? "true" : "false"));
      paintKey();
      drawField();
      if (flow) flow.getContext("2d").clearRect(0, 0, flow.width, flow.height);
      wake();
    }));
    document.getElementById("cmPlay").addEventListener("click", e => { e.stopPropagation(); togglePlay(); });
    document.getElementById("cmHour").addEventListener("input", e => { stopPlay(); goHour(+e.target.value); });
    const hero = document.getElementById("hero");
    if (hero && !document.getElementById("cmVerdict")) {
      const v = document.createElement("section");
      v.id = "cmVerdict"; v.className = "cm-verdict";
      v.setAttribute("aria-live", "polite");
      v.innerHTML = '<p class="cm-k">Dover Strait</p><p class="cm-h">Reading the Channel…</p><p class="cm-why">Wind and waves, and whether small boats are likely to set out.</p>';
      hero.append(v);
      v.addEventListener("click", e => {
        if (e.target.closest(".cm-strip")) return;
        const chip = document.getElementById("chipMap");
        if (chip) chip.click();
      });
    }
  }

  function mount(opts) {
    if (!window.L) return;
    reduced = !!(opts && opts.reduced) || matchMedia("(prefers-reduced-motion: reduce)").matches;
    onReady = opts && opts.onReady;
    buildControls();
    const el = document.getElementById("lmap");
    if (!el || map) return;
    const touch = matchMedia("(hover: none)").matches;
    map = L.map(el, {
      zoomControl: false, attributionControl: true, scrollWheelZoom: false, keyboard: false,
      dragging: !touch, touchZoom: false, doubleClickZoom: !touch, boxZoom: false,
      maxBounds: [[48.6, -2.4], [52.6, 4.6]], maxBoundsViscosity: 0.85, minZoom: 6, maxZoom: 12
    });
    map.attributionControl.setPrefix(false);
    L.tileLayer("https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}", {
      maxZoom: 16,
      attribution: 'Map © <a href="https://www.esri.com/">Esri</a> · Weather © <a href="https://open-meteo.com/">Open-Meteo</a>'
    }).addTo(map);
    L.control.zoom({ position: "bottomright" }).addTo(map);
    pane = map.createPane("wx");
    pane.style.zIndex = "250";
    pane.style.pointerEvents = "none";
    heat = document.createElement("canvas"); heat.className = "cm-canvas";
    flow = document.createElement("canvas"); flow.className = "cm-canvas";
    pane.append(heat, flow);
    const routes = map.createPane("routes");
    routes.style.zIndex = "420";
    routes.style.pointerEvents = "none";
    ROUTES.forEach(pair => L.polyline(pair, { pane: "routes", color: "#fff", weight: 2, opacity: 0.75, dashArray: "2 8", lineCap: "round" }).addTo(map));
    TOWNS.forEach(([name, lat, lon]) => L.marker([lat, lon], {
      interactive: false, keyboard: false,
      icon: L.divIcon({ className: "cm-town", html: "<i></i><span>" + name + "</span>", iconSize: [0, 0] })
    }).addTo(map));
    BEACHES.forEach(([name, lat, lon, note]) => L.marker([lat, lon], {
      keyboard: false, title: name,
      icon: L.divIcon({ className: "cm-beach", html: "<b></b><i></i>", iconSize: [24, 24], iconAnchor: [12, 12] })
    }).bindTooltip("<b>" + name + "</b><br>" + note, { direction: "top", offset: [0, -8], className: "am-launch-tip" }).addTo(map));
    map.on("click", e => showPoint(e.latlng));
    map.on("mousemove", e => showHover(e));
    map.on("mouseout", () => { const b = document.getElementById("amHover"); if (b) b.classList.add("off"); });
    map.on("zoomstart", () => { pane.style.opacity = "0"; });
    map.on("zoomend", () => { pane.style.opacity = ""; layout(); drawField(); wake(); });
    map.on("moveend", () => { if (pane.style.opacity !== "0") { layout(); drawField(); } });
    map.on("popupclose", () => { pinned = null; if (showPoint.pin) { showPoint.pin.remove(); showPoint.pin = null; } });
    const x = document.getElementById("amSheetX");
    if (x) x.addEventListener("click", e => { e.stopPropagation(); document.getElementById("amSheet").hidden = true; pinned = null; if (showPoint.pin) { showPoint.pin.remove(); showPoint.pin = null; } });
    fitView();
    layout();
    placeChrome();
    load();
    document.addEventListener("visibilitychange", wake);
    if ("ResizeObserver" in window) new ResizeObserver(() => resize()).observe(document.getElementById("hero"));
  }
  let resizeT = 0, skipFit = false;
  function resize(fromMove) {
    clearTimeout(resizeT);
    if (fromMove) { layout(); drawField(); placeChrome(); return; }
    resizeT = setTimeout(() => {
      if (!map) return;
      fitView();
      layout();
      drawField();
      placeChrome();
      wake();
    }, 60);
  }
  window.CCWeather = {
    mount,
    resize: () => resize(),
    reload: () => load(),
    close: () => { if (map) map.closePopup(); const s = document.getElementById("amSheet"); if (s) s.hidden = true; }
  };
})();
